# ✨ FURNIRO E-COMMERCE - COMPLETE REACT.JS SETUP GUIDE

## 📦 Project Setup Instructions

### **Step 1: Create New React Project with Vite**

```bash
npm create vite@latest furniro-ecommerce -- --template react
cd furniro-ecommerce
npm install
```

### **Step 2: Install All Required Dependencies**

```bash
npm install bootstrap react-bootstrap react-router-dom react-icons axios
```

### **Step 3: Update `src/main.jsx`**

```javascript
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import 'bootstrap/dist/css/bootstrap.min.css'
import './App.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
```

### **Step 4: Create Project Folder Structure**

Create these folders in `src/`:

```
src/
├── components/
│   ├── Navbar.jsx
│   ├── Navbar.css
│   ├── Footer.jsx
│   ├── Footer.css
│   ├── ProductCard.jsx
│   ├── ProductCard.css
│   ├── HeroSection.jsx
│   ├── HeroSection.css
│   ├── BrowseRange.jsx
│   ├── BrowseRange.css
│   ├── FeaturesBar.jsx
│   ├── FeaturesBar.css
│   └── Pagination.jsx
│   └── Pagination.css
├── pages/
│   ├── Home.jsx
│   ├── Home.css
│   ├── Shop.jsx
│   ├── Shop.css
│   ├── Cart.jsx
│   ├── Checkout.jsx
│   ├── Contact.jsx
│   └── Blog.jsx
├── App.jsx
├── App.css
└── main.jsx
```

### **Step 5: Copy All Component Files**

Copy all the provided component files into their respective directories.

### **Step 6: Run the Project**

```bash
npm run dev
```

Your project will be available at `http://localhost:5173`

---

## 🎨 Color Scheme (Furniro Branding)

```css
--primary: #b8860b (Gold/Brown)
--secondary: #f4f1de (Light Cream)
--dark: #333333 (Dark Gray)
--light: #f9f9f9 (Off White)
--border: #d0d0d0 (Light Border)
--success: #27ae60 (Green)
--error: #e74c3c (Red)
```

---

## 📱 Responsive Design Breakpoints

- **Desktop**: ≥992px (`lg`)
- **Tablet**: ≥768px (`md`)
- **Mobile**: ≥576px (`sm`)
- **Extra Small**: <576px (`xs`)

---

## 🚀 Key Features Implemented

### ✅ **1. Component Architecture**
- **Navbar**: Navigation with responsive hamburger menu
- **Footer**: Company info, links, and newsletter signup
- **ProductCard**: Reusable card with discount badges and hover effects
- **HeroSection**: Dynamic banner with CTA button
- **BrowseRange**: Category browsing section
- **FeaturesBar**: Key benefits display
- **Pagination**: Page navigation for product grids

### ✅ **2. Pages Implemented**
- **Home Page**: Hero + Browse Range + Products Grid + Room Inspiration + Gallery + Features
- **Shop Page**: Product grid with filters, sorting, view toggle, and pagination

### ✅ **3. API Integration**
- **DummyJSON Furniture API**: `https://dummyjson.com/products/category/furniture`
- Dynamic product fetching with `axios` and `useEffect`
- Real product data displayed in product cards and grids

### ✅ **4. State Management**
- `useState` for managing products, filters, current page, view type
- `useEffect` for fetching data and filtering/sorting updates

### ✅ **5. Responsive Design**
- Bootstrap grid system with responsive columns
- Mobile-first approach with media queries
- Hamburger menu for mobile navigation
- Touch-friendly buttons and spacing

### ✅ **6. Dynamic Rendering**
- Products rendered using `.map()` method
- Product discounts and badges applied dynamically
- Sorting and filtering functionality
- Pagination with dynamic page calculations

---

## 🔧 Available npm Commands

```bash
# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Lint code
npm run lint
```

---

## 📝 File Structure Explanation

### **components/** Directory
Reusable UI components:
- **Navbar.jsx**: Main navigation header
- **Footer.jsx**: Footer with links and info
- **ProductCard.jsx**: Single product display
- **HeroSection.jsx**: Banner section
- **BrowseRange.jsx**: Category browsing
- **FeaturesBar.jsx**: Benefits section
- **Pagination.jsx**: Page numbers

### **pages/** Directory
Full page components:
- **Home.jsx**: Landing page with all sections
- **Shop.jsx**: Product listing with filters
- Cart, Checkout, Contact, Blog (structure ready)

### **App.jsx**
Main app component with React Router setup

---

## 🛍️ Product Data Structure

Each product from the API has:
```javascript
{
  id: number,
  title: string,
  description: string,
  price: number,
  thumbnail: string,
  rating: number,
  // ... other properties
}
```

---

## 🎯 Additional Features to Add (Optional)

1. **Product Detail Page**
   ```jsx
   <Route path="/product/:id" element={<ProductDetail />} />
   ```

2. **Cart Functionality**
   - Add to cart button integration
   - LocalStorage for cart persistence
   - Checkout form

3. **Search & Filter**
   - Search bar in navbar
   - Advanced filters in shop page
   - Price range slider

4. **User Authentication**
   - Login/Register pages
   - User profile section
   - Wishlist functionality

5. **Wishlist Feature**
   - Heart icon toggle
   - Wishlist page
   - LocalStorage persistence

---

## 🔗 API Documentation

### DummyJSON Furniture API

**Base URL**: `https://dummyjson.com/products/category/furniture`

**Response Format**:
```json
{
  "products": [
    {
      "id": 1,
      "title": "Product Name",
      "description": "...",
      "price": 299.99,
      "thumbnail": "image_url",
      "rating": 4.5,
      ...
    }
  ],
  "total": 32,
  "skip": 0,
  "limit": 30
}
```

---

## ⚠️ Common Issues & Solutions

### **Issue**: Products not loading
**Solution**: Check internet connection and API endpoint. Open browser console for errors.

### **Issue**: Images not showing
**Solution**: Ensure proper image URLs from API. Use fallback images if needed.

### **Issue**: Responsive layout issues
**Solution**: Clear browser cache and rebuild. Check Bootstrap imports.

### **Issue**: Router not working
**Solution**: Ensure `<BrowserRouter>` wraps all routes in `App.jsx`.

---

## 📦 Dependencies Versions

```json
{
  "react": "^18.x",
  "react-dom": "^18.x",
  "react-router-dom": "^6.x",
  "bootstrap": "^5.x",
  "react-bootstrap": "^2.x",
  "react-icons": "^4.x",
  "axios": "^1.x"
}
```

---

## 🎓 Learning Points

This project demonstrates:
- ✅ Component-based architecture
- ✅ React Hooks (useState, useEffect)
- ✅ React Router for multi-page navigation
- ✅ API integration with axios
- ✅ Dynamic rendering with .map()
- ✅ Responsive design with Bootstrap
- ✅ CSS-in-JS and CSS modules
- ✅ State management patterns
- ✅ Conditional rendering
- ✅ Event handling

---

## 📞 Support

For issues or questions:
1. Check the browser console for errors
2. Verify all dependencies are installed
3. Ensure API endpoint is accessible
4. Check responsive design on different screen sizes
5. Review component props and state management

---

## ✅ Testing Checklist

- [ ] Home page loads with hero section
- [ ] Browse Range categories display
- [ ] Products load from API dynamically
- [ ] Product cards show discounts/badges
- [ ] Hover effects work on products
- [ ] Shop page filters and sorting work
- [ ] Pagination navigates correctly
- [ ] Navbar navigation links work
- [ ] Mobile hamburger menu toggles
- [ ] Footer displays correctly
- [ ] All images load properly
- [ ] Responsive design works on mobile/tablet

---

**Happy Coding! 🚀**
