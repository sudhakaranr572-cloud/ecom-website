# 🛋️ FURNIRO - React.js E-Commerce Furniture Store

A modern, responsive furniture e-commerce platform built with React.js, Bootstrap, and integrated with the DummyJSON API.

## ✨ Features

### 🏠 **Home Page**
- Dynamic hero section with call-to-action
- Browse The Range category section
- Product grid with discount badges and new indicators
- Room inspiration showcase
- Furniture photo gallery (#FurniturePhoto)
- Features bar highlighting key benefits

### 🛍️ **Shop Page**
- Product grid layout with hover effects
- Dynamic product filtering and sorting
- View toggle (Grid/List view)
- Pagination for product navigation
- Responsive product cards with pricing
- Stock indicators and discounts

### 📦 **Product Features**
- Product card with hover overlay actions
- Add to cart functionality
- Wishlist toggle
- Product comparison
- Dynamic discount display
- Star rating display

### 🎨 **Design & UI**
- Furniro branded color scheme (Gold #b8860b)
- Bootstrap 5 responsive grid system
- Mobile-first responsive design
- Smooth animations and transitions
- Professional typography with hierarchy
- Consistent spacing and alignment

### 📱 **Responsive Design**
- Desktop (≥992px): Full-width layouts
- Tablet (≥768px): Optimized columns
- Mobile (<576px): Single column layouts
- Touch-friendly buttons and spacing
- Hamburger menu navigation

## 🚀 Quick Start

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn

### Installation

1. **Clone or create the project**
   ```bash
   npm create vite@latest furniro-ecommerce -- --template react
   cd furniro-ecommerce
   ```

2. **Install dependencies**
   ```bash
   npm install bootstrap react-bootstrap react-router-dom react-icons axios
   ```

3. **Copy all project files** into the `src` directory

4. **Start development server**
   ```bash
   npm run dev
   ```

5. **Open browser**
   - Navigate to `http://localhost:5173`

## 📁 Project Structure

```
src/
├── components/
│   ├── Navbar.jsx              # Navigation header
│   ├── Footer.jsx              # Footer section
│   ├── ProductCard.jsx         # Product display card
│   ├── HeroSection.jsx         # Hero banner
│   ├── BrowseRange.jsx         # Category browsing
│   ├── FeaturesBar.jsx         # Benefits showcase
│   └── Pagination.jsx          # Page navigation
│
├── pages/
│   ├── Home.jsx                # Home page with all sections
│   ├── Shop.jsx                # Product listing with filters
│   ├── Cart.jsx                # Shopping cart (structure ready)
│   ├── Checkout.jsx            # Checkout form (structure ready)
│   ├── Contact.jsx             # Contact page (structure ready)
│   └── Blog.jsx                # Blog listing (structure ready)
│
├── App.jsx                     # Main app with routing
├── App.css                     # App global styles
├── main.jsx                    # Entry point
└── index.css                   # Global styling
```

## 🎨 Design System

### Colors
```
Primary:      #b8860b (Gold/Brown)
Dark:         #333333 (Dark Gray)
Light:        #f9f9f9 (Off White)
Success:      #27ae60 (Green)
Error:        #e74c3c (Red)
```

### Typography
- **Headings**: Bold (700), line-height 1.3
- **Body Text**: Regular (400), line-height 1.6
- **Font**: Segoe UI, Tahoma, Geneva

### Spacing
- Grid: Bootstrap 12-column
- Gutters: 20px
- Padding: 15px - 60px (sections)
- Margins: 10px - 60px (elements)

## 🔌 API Integration

### Data Source
- **API**: DummyJSON Furniture Category
- **Endpoint**: `https://dummyjson.com/products/category/furniture`
- **Method**: GET
- **Response**: JSON with product array

### Product Structure
```javascript
{
  id: number,
  title: string,
  description: string,
  price: number,
  thumbnail: string,
  rating: number,
  discount: number (optional)
}
```

## 📦 Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| React | ^18.2.0 | UI Framework |
| React DOM | ^18.2.0 | DOM Rendering |
| React Router | ^6.15.0 | Navigation |
| Bootstrap | ^5.3.2 | Styling Framework |
| React Bootstrap | ^2.10.0 | Bootstrap Components |
| React Icons | ^4.12.0 | Icon Library |
| Axios | ^1.6.0 | HTTP Client |
| Vite | ^5.0.2 | Build Tool |

## 🎯 Component Overview

### **Navbar**
- Logo branding
- Navigation links (Home, Shop, About, Contact)
- User icons (account, search, wishlist, cart)
- Responsive hamburger menu

### **Footer**
- Company information
- Quick links
- Newsletter subscription
- Features showcase

### **ProductCard**
- Product image with overlay
- Discount badge (-30%, New)
- Product title and description
- Pricing (current and original)
- Star rating
- Add to cart button
- Hover effects

### **HeroSection**
- Full-width banner image
- Overlay text with CTA
- Responsive text sizing

### **BrowseRange**
- Three category cards (Dining, Living, Bedroom)
- Hover zoom effect
- Navigation links

### **FeaturesBar**
- Four feature items with icons
- High Quality, Warranty, Shipping, Support
- Responsive grid layout

### **Pagination**
- Dynamic page numbers
- Next/Previous navigation
- Active page highlighting

## 🛠️ Available Scripts

```bash
# Development server with hot reload
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Lint code
npm run lint
```

## 🔧 Configuration Files

### **vite.config.js**
- React plugin
- Port: 5173
- Auto-open browser

### **package.json**
- All dependencies listed
- Scripts configured
- Project metadata

## 📱 Responsive Breakpoints

```css
/* Desktop */
@media (min-width: 992px) {
  .col-lg-3 { width: 25%; }
  .col-lg-4 { width: 33.33%; }
}

/* Tablet */
@media (min-width: 768px) and (max-width: 991px) {
  .col-md-4 { width: 33.33%; }
  .col-md-6 { width: 50%; }
}

/* Mobile */
@media (max-width: 767px) {
  .col-sm-12 { width: 100%; }
}
```

## 🚀 Performance Optimizations

- ✅ Image optimization with thumbnail URLs
- ✅ Lazy loading ready (can be added)
- ✅ Bootstrap CSS included only once
- ✅ Component-based code splitting
- ✅ Efficient state management
- ✅ Memoization ready (React.memo can be added)

## 🔐 Security Considerations

- ✅ No sensitive data in frontend
- ✅ API calls through axios with error handling
- ✅ Input validation ready (can be added)
- ✅ XSS protection via React JSX
- ✅ CSRF tokens ready (backend integration)

## 🧪 Testing Checklist

- [ ] Hero section displays correctly
- [ ] Products load from API
- [ ] Product cards show discount badges
- [ ] Hover effects work smoothly
- [ ] Navigation links function
- [ ] Mobile menu opens/closes
- [ ] Pagination works
- [ ] Sorting options work
- [ ] Filter options work
- [ ] Footer displays correctly
- [ ] All images load
- [ ] Responsive on all screen sizes

## 🎓 Learning Points

This project teaches:
- Component-based React architecture
- React Hooks (useState, useEffect)
- React Router v6 navigation
- Bootstrap grid system
- CSS-in-JS and CSS modules
- API integration with axios
- Dynamic rendering with .map()
- Responsive design patterns
- State management
- Event handling

## 🐛 Troubleshooting

| Issue | Solution |
|-------|----------|
| Products not loading | Check API connectivity and console errors |
| Images not displaying | Verify image URLs and network requests |
| Styling issues | Clear cache, rebuild, check Bootstrap import |
| Router not working | Verify BrowserRouter wraps all routes |
| Responsive layout broken | Check Bootstrap grid classes |

## 📚 Additional Resources

- [React Documentation](https://react.dev)
- [Bootstrap 5 Docs](https://getbootstrap.com/docs)
- [React Router v6](https://reactrouter.com)
- [React Icons](https://react-icons.github.io/react-icons)
- [DummyJSON API](https://dummyjson.com)
- [Vite Guide](https://vitejs.dev)

## 🔄 Future Enhancements

- [ ] Product detail page with specifications
- [ ] Shopping cart functionality
- [ ] Checkout process
- [ ] User authentication
- [ ] Wishlist feature
- [ ] Advanced filters (price range, ratings)
- [ ] Search functionality
- [ ] Blog section
- [ ] Contact form submission
- [ ] Order tracking
- [ ] Payment integration
- [ ] User reviews and ratings

## 📄 License

This project is created for educational purposes.

## 👨‍💻 Author

Created as a practical assessment for React.js and Figma design implementation.

---

**Happy Coding! 🚀**

For questions or support, refer to the troubleshooting section or check component documentation in the code comments.
