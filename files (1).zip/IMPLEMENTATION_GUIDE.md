# 🎯 FURNIRO REACT.JS - COMPLETE IMPLEMENTATION GUIDE

## 📋 Table of Contents
1. Project Setup
2. Component Implementation Details
3. State Management Examples
4. API Integration
5. Styling & Responsive Design
6. Deployment Guide
7. Best Practices

---

## 1️⃣ PROJECT SETUP - STEP BY STEP

### Step 1: Initialize Vite React Project

```bash
# Create new Vite project
npm create vite@latest furniro-ecommerce -- --template react

# Navigate to project
cd furniro-ecommerce

# Install dependencies
npm install
```

### Step 2: Install Required Packages

```bash
# Install all dependencies in one command
npm install bootstrap react-bootstrap react-router-dom react-icons axios

# Or individually:
npm install bootstrap
npm install react-bootstrap
npm install react-router-dom
npm install react-icons
npm install axios
```

### Step 3: Verify Installation

```bash
npm list react-router-dom
npm list bootstrap
npm list react-icons
npm list axios
```

### Step 4: Project Structure

```
furniro-ecommerce/
├── public/
├── src/
│   ├── components/
│   │   ├── Navbar.jsx
│   │   ├── Navbar.css
│   │   ├── Footer.jsx
│   │   ├── Footer.css
│   │   ├── ProductCard.jsx
│   │   ├── ProductCard.css
│   │   ├── HeroSection.jsx
│   │   ├── HeroSection.css
│   │   ├── BrowseRange.jsx
│   │   ├── BrowseRange.css
│   │   ├── FeaturesBar.jsx
│   │   ├── FeaturesBar.css
│   │   ├── Pagination.jsx
│   │   └── Pagination.css
│   ├── pages/
│   │   ├── Home.jsx
│   │   ├── Home.css
│   │   ├── Shop.jsx
│   │   └── Shop.css
│   ├── App.jsx
│   ├── App.css
│   ├── main.jsx
│   └── index.css
├── index.html
├── package.json
├── vite.config.js
└── README.md
```

---

## 2️⃣ COMPONENT IMPLEMENTATION DETAILS

### **Navbar Component Example**

The Navbar is the header component with navigation and icons.

**Key Features:**
- Responsive hamburger menu for mobile
- React Icons for visual elements
- React Router Link for navigation
- Sticky positioning

**State Management:**
```javascript
const [expanded, setExpanded] = useState(false);
```

**Icons Used:**
- FiMenu - Hamburger menu
- FiX - Close menu
- FiUser - Account
- FiSearch - Search
- FiHeart - Wishlist
- FiShoppingCart - Cart

### **ProductCard Component Example**

Displays individual furniture products with interactive features.

**Props Received:**
```javascript
{
  product: {
    id, title, description, price, thumbnail, rating
  },
  discount: number (0-100),
  badge: string ('New' or '')
}
```

**Features:**
- Hover overlay with action buttons
- Discount calculation and display
- Star rating system
- Price formatting with currency

**Interactive Elements:**
```javascript
// Add to cart button
<button className="add-to-cart-btn">
  <FiShoppingCart /> Add to cart
</button>

// Action icons
<button className="icon-btn">
  <FiHeart /> Wishlist
</button>
```

### **Home Page Structure**

```
Home Page
├── HeroSection (Hero Banner)
├── BrowseRange (Category Cards)
├── ProductSection
│   ├── Section Header
│   ├── Product Grid (mapped from API)
│   └── Show More Button
├── InspirationSection (Room Showcase)
├── GallerySection (Photo Grid)
└── FeaturesBar (Benefits)
```

### **Shop Page Features**

**Filtering & Sorting:**
```javascript
const sortBy = (sortType) => {
  switch(sortType) {
    case 'price-low':
      return products.sort((a,b) => a.price - b.price);
    case 'price-high':
      return products.sort((a,b) => b.price - a.price);
    case 'newest':
      return products.reverse();
    default:
      return products;
  }
}
```

**View Toggle:**
```javascript
{viewType === 'grid' ? (
  <Row className="products-grid">
    {/* 4 products per row */}
  </Row>
) : (
  <Row className="products-list">
    {/* 1 product per row */}
  </Row>
)}
```

---

## 3️⃣ STATE MANAGEMENT EXAMPLES

### **Home Page State**

```javascript
import { useState, useEffect } from 'react';

export default function Home() {
  // Products from API
  const [products, setProducts] = useState([]);
  
  // Loading state
  const [loading, setLoading] = useState(true);
  
  // Fetch data on component mount
  useEffect(() => {
    fetchProducts();
  }, []); // Empty dependency array = run once on mount
  
  const fetchProducts = async () => {
    try {
      const response = await axios.get(
        'https://dummyjson.com/products/category/furniture'
      );
      setProducts(response.data.products.slice(0, 8));
      setLoading(false);
    } catch (error) {
      console.error('Error fetching products:', error);
      setLoading(false);
    }
  };
  
  return (
    <div>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <Row>
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </Row>
      )}
    </div>
  );
}
```

### **Shop Page State**

```javascript
export default function Shop() {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [sortBy, setSortBy] = useState('default');
  const [showPerPage, setShowPerPage] = useState(16);
  
  // Fetch products
  useEffect(() => {
    fetchProducts();
  }, []);
  
  // Filter and sort when products change
  useEffect(() => {
    filterAndSortProducts();
  }, [products, sortBy]);
  
  const filterAndSortProducts = () => {
    let sorted = [...products];
    
    switch(sortBy) {
      case 'price-low':
        sorted.sort((a,b) => a.price - b.price);
        break;
      case 'price-high':
        sorted.sort((a,b) => b.price - a.price);
        break;
      default:
        break;
    }
    
    setFilteredProducts(sorted);
  };
  
  // Pagination calculation
  const totalPages = Math.ceil(filteredProducts.length / showPerPage);
  const startIndex = (currentPage - 1) * showPerPage;
  const displayedProducts = filteredProducts.slice(
    startIndex, 
    startIndex + showPerPage
  );
}
```

---

## 4️⃣ API INTEGRATION

### **Axios Setup**

```javascript
import axios from 'axios';

// Create axios instance with defaults
const api = axios.create({
  baseURL: 'https://dummyjson.com',
  timeout: 5000,
});

// Add request interceptor
api.interceptors.request.use(
  config => {
    console.log('Request:', config);
    return config;
  },
  error => Promise.reject(error)
);

// Add response interceptor
api.interceptors.response.use(
  response => response,
  error => {
    console.error('API Error:', error);
    return Promise.reject(error);
  }
);

export default api;
```

### **Fetch Furniture Products**

```javascript
const fetchFurnitureProducts = async () => {
  try {
    const response = await axios.get(
      'https://dummyjson.com/products/category/furniture'
    );
    
    // Response structure:
    // {
    //   products: [...],
    //   total: number,
    //   skip: number,
    //   limit: number
    // }
    
    console.log('Products fetched:', response.data.products.length);
    setProducts(response.data.products);
  } catch (error) {
    console.error('Error fetching products:', error.message);
    // Set default products or show error message
  }
};
```

### **Error Handling**

```javascript
const fetchProducts = async () => {
  setLoading(true);
  try {
    const response = await axios.get(
      'https://dummyjson.com/products/category/furniture'
    );
    setProducts(response.data.products);
    setError(null);
  } catch (error) {
    if (error.response) {
      // Server responded with error status
      setError(`Error: ${error.response.status}`);
    } else if (error.request) {
      // Request made but no response received
      setError('No response from server. Check internet connection.');
    } else {
      // Error in request setup
      setError('Error: ' + error.message);
    }
  } finally {
    setLoading(false);
  }
};
```

---

## 5️⃣ STYLING & RESPONSIVE DESIGN

### **Bootstrap Grid System**

```jsx
// Desktop: 4 columns (3 per row)
// Tablet: 6 columns (2 per row)
// Mobile: 12 columns (1 per row)

<Row className="products-grid">
  {products.map((product) => (
    <Col lg={3} md={6} sm={12} key={product.id}>
      <ProductCard product={product} />
    </Col>
  ))}
</Row>
```

### **CSS Variables**

```css
:root {
  --primary-color: #b8860b;
  --dark-color: #333333;
  --light-color: #f9f9f9;
  --border-color: #d0d0d0;
  --text-color: #666666;
}

/* Usage */
.button {
  background-color: var(--primary-color);
  color: var(--light-color);
}
```

### **Responsive Media Queries**

```css
/* Desktop (≥992px) */
@media (min-width: 992px) {
  .product-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
  }
}

/* Tablet (≥768px and <992px) */
@media (min-width: 768px) and (max-width: 991px) {
  .product-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

/* Mobile (<768px) */
@media (max-width: 767px) {
  .product-grid {
    grid-template-columns: 1fr;
  }
}
```

### **Hover Effects**

```css
.product-card {
  transition: all 0.3s ease;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.product-card:hover {
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
  transform: translateY(-5px);
}
```

---

## 6️⃣ DEPLOYMENT GUIDE

### **Build for Production**

```bash
# Create optimized build
npm run build

# Output directory: dist/
```

### **Deploy to Vercel** (Recommended)

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Link to production
vercel --prod
```

### **Deploy to Netlify**

```bash
# Install Netlify CLI
npm install -g netlify-cli

# Deploy
netlify deploy --prod --dir=dist
```

### **Deploy to GitHub Pages**

```bash
# Update vite.config.js
export default defineConfig({
  base: '/furniro-ecommerce/',
  // ... rest of config
})

# Build and deploy
npm run build
# Then push dist folder to gh-pages branch
```

---

## 7️⃣ BEST PRACTICES

### **Component Structure**

```javascript
// Good: Separate concerns
export default function ProductCard({ product, discount }) {
  // State
  const [isHovered, setIsHovered] = useState(false);
  
  // Effects
  useEffect(() => {
    // Side effects here
  }, []);
  
  // Methods
  const handleClick = () => { /* ... */ };
  
  // Render
  return (
    <div className="product-card">
      {/* JSX here */}
    </div>
  );
}
```

### **Performance Optimization**

```javascript
// Use useMemo for expensive calculations
const discountedPrice = useMemo(() => {
  return (product.price * (1 - discount / 100)).toFixed(2);
}, [product.price, discount]);

// Use useCallback for stable function references
const handleAddToCart = useCallback(() => {
  // Add to cart logic
}, [product.id]);

// Lazy load images
<img 
  src={product.thumbnail}
  loading="lazy"
  alt={product.title}
/>
```

### **Code Quality**

```javascript
// ✅ Good: Clear variable names
const displayedProducts = filteredProducts.slice(
  startIndex, 
  startIndex + showPerPage
);

// ❌ Bad: Unclear variable names
const dp = fp.slice(si, si + spp);

// ✅ Good: Comments for complex logic
// Calculate total pages based on products and items per page
const totalPages = Math.ceil(filteredProducts.length / showPerPage);

// ✅ Good: Error handling
try {
  await fetchProducts();
} catch (error) {
  console.error('Failed to fetch products:', error);
  setError('Could not load products. Please try again.');
}
```

### **Accessibility**

```jsx
// Add aria labels
<button aria-label="Open shopping cart">
  <FiShoppingCart />
</button>

// Proper heading hierarchy
<h1>Main Title</h1>
<h2>Section Title</h2>
<h3>Subsection Title</h3>

// Alt text for images
<img 
  src={product.thumbnail}
  alt={`${product.title} furniture`}
/>

// Keyboard navigation
<input 
  type="text"
  placeholder="Search products"
  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
/>
```

---

## 🧪 Testing Checklist

Before submitting, verify:

- [ ] **Functionality**
  - [ ] All pages load without errors
  - [ ] Products fetch from API
  - [ ] Sorting works correctly
  - [ ] Pagination navigates properly
  - [ ] Navigation links work

- [ ] **Design**
  - [ ] Matches Figma design closely
  - [ ] Colors are correct (#b8860b primary)
  - [ ] Spacing is consistent
  - [ ] Typography hierarchy is clear

- [ ] **Responsive**
  - [ ] Desktop view (1200px+)
  - [ ] Tablet view (768px)
  - [ ] Mobile view (375px)
  - [ ] Hamburger menu works

- [ ] **Performance**
  - [ ] Page loads quickly
  - [ ] No console errors
  - [ ] Images load properly
  - [ ] Smooth animations

- [ ] **Code Quality**
  - [ ] Components are reusable
  - [ ] State management is clean
  - [ ] No hardcoded values
  - [ ] Consistent code style

---

## 📞 Troubleshooting

| Problem | Solution |
|---------|----------|
| Products not loading | Check API endpoint and network requests in DevTools |
| Styling not applied | Clear cache, verify Bootstrap import, restart dev server |
| Router errors | Check BrowserRouter wraps all routes |
| Images not showing | Verify image URLs in API response |
| Mobile layout broken | Check responsive classes (col-lg-3, col-md-6, etc.) |

---

## 🎓 Next Steps

After completing the basic implementation:

1. Add Product Detail page
2. Implement Shopping Cart functionality
3. Create Checkout page
4. Add User Authentication
5. Implement Search functionality
6. Add Advanced Filters
7. Create Contact form
8. Build Blog section

---

**🚀 Ready to deploy! Good luck with your React.js practical assessment!**
